# Kotlin-Calculator
Kotlin Calculator is an simple calculator that performs various complex calculations with ease. This app is made in Kotlin on top of Android Platform. Fork, learn and use it for your projects.

## Screenshots:
<div>
<img src="./Screenshot_2019-10-21-13-13-27-595_cdn.mykotlin.png" title="Kotlin Calculator example"/>
</div>

## License: 
MIT (Do what you want. :P)
